package com.example.sosmeddicoding.ui.story

import androidx.lifecycle.liveData
import com.example.sosmeddicoding.data.model.ResponseAddNewStory
import com.example.sosmeddicoding.data.model.ResponseGetAllStory
import com.example.sosmeddicoding.data.service.ApiService
import com.example.sosmeddicoding.utils.AuthPreferences
import com.example.sosmeddicoding.utils.ResultViewModel
import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File

class StoryRepo(private val apiService: ApiService, authPreferences: AuthPreferences) {
    suspend fun getAllStories() : ResponseGetAllStory {
        return apiService.getAllStories()
    }

    fun uploadImage(imageFile: File, description: String) = liveData {
        emit(ResultViewModel.Loading)
        val requestBody = description.toRequestBody("text/plain".toMediaType())
        val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "photo",
            imageFile.name,
            requestImageFile
        )
        try {
            val successResponse = apiService.postStory(multipartBody, requestBody)
            emit(ResultViewModel.Success(successResponse))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, ResponseAddNewStory::class.java)
            emit(errorResponse.message?.let { ResultViewModel.Error(it) })
        }

    }

    companion object {
        private var instance: StoryRepo? = null

        fun getInstance(apiService: ApiService, authPreferences: AuthPreferences): StoryRepo {
            return instance ?: synchronized(this) {
                instance ?: StoryRepo(apiService, authPreferences).also { instance = it }
            }
        }
    }
}