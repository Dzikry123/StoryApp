package com.example.sosmeddicoding.ui.camera

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.sosmeddicoding.ui.story.StoryRepo
import java.io.File

class UploadViewModel(private val storyRepo: StoryRepo): ViewModel() {
    fun uploadImage(file: File, desc: String) = storyRepo.uploadImage(file, desc)
}

class UploadViewModelFactory(private val storyRepo: StoryRepo) :
    ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UploadViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UploadViewModel(storyRepo) as T
        }
        throw IllegalAccessException("Unkwon ViewModel :" + modelClass.name)
    }
}