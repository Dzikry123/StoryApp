package com.example.sosmeddicoding.ui.story

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.example.sosmeddicoding.data.di.Injection
import com.example.sosmeddicoding.data.model.ErrorResponse
import com.example.sosmeddicoding.data.model.ListStoryItem
import com.example.sosmeddicoding.data.model.ResponseGetAllStory
import com.example.sosmeddicoding.data.repo.AuthRepo
import com.example.sosmeddicoding.ui.WelcomeViewModel
import com.example.sosmeddicoding.utils.AuthPreferences
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.HttpException

class StoryViewModel(private val storyRepo: StoryRepo) : ViewModel() {
    val allStories: LiveData<ResponseGetAllStory> = liveData {
        val result = storyRepo.getAllStories()
        emit(result)
    }
}

class StoryViewModelFactory(private val storyRepo: StoryRepo) :
    ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return StoryViewModel(storyRepo) as T
        }
        throw IllegalAccessException("Unkwon ViewModel :" + modelClass.name)
    }
}