package com.example.sosmeddicoding.ui.story

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.dicodingsocialmedia.databinding.ListPostBinding
import com.example.sosmeddicoding.data.model.ListStoryItem

class StoryAdapter(private val data: MutableList<ListStoryItem> = mutableListOf(),
                  private val listener: (ListStoryItem) -> Unit) :
    RecyclerView.Adapter<StoryAdapter.UserViewHolder>() {



    fun setData(data: MutableList<ListStoryItem>) {
        this.data.clear()
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    class UserViewHolder(private val binding:ListPostBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ListStoryItem, ) {
            binding.imageUser.load(item.photoUrl)
            val partialDescription = item.description?.take(50)
            binding.tvUserSlice.text = item.name
            binding.tvDesc.text = partialDescription
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        return UserViewHolder(ListPostBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val item = data[position]
        holder.bind(item)
        holder.itemView.setOnClickListener{
            listener(item)
        }
    }
}